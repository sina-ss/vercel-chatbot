import Logo from './components/Logo';
import './globals.css';

export const metadata = {
  title: 'EyeSP.live | Chatbot',
  description: 'eyesp.live chatbot. one bot for all of the internet issues.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className='flex flex-col justify-center items-center'>
        <Logo/>
        {children}
        </body>
    </html>
  );
}
