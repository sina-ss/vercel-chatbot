"use client";

import { useChat } from "ai/react";
import { cn } from "./lib/utils";

export default function Chat() {
  const { messages, input, handleInputChange, handleSubmit, data } = useChat();
  return (
    <div className="flex flex-col items-center w-[80%] h-[80%] py-24 px-6 mx-auto stretch bg-[#1A1A1A] rounded-xl">
      {messages.length > 0
        ? messages.map((m) => (
            <div
              key={m.id}
              className={cn("whitespace-pre-wrap text-neutral-50 my-2", {
                "self-end bg-[#0C6087] px-7 py-4 rounded-xl": m.role === "user",
                "self-start bg-[#262626] px-7 py-4 rounded-xl": m.role != "user",
              })}
            >
              {m.content}
            </div>
          ))
        : null}

      <form
        onSubmit={handleSubmit}
        className="fixed w-full bottom-0 text-center"
      >
        <input
          className="w-full max-w-md p-2 mb-8 border border-gray-300 rounded shadow-xl"
          value={input}
          placeholder="گفت و گو را از اینجا شروع کنید..."
          onChange={handleInputChange}
        />
      </form>
    </div>
  );
}
