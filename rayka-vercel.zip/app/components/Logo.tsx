import Link from "next/link";
import React from "react";

const Logo = () => {
  return (
    <Link href="https://eyesp.live" className="rounded-[2rem] border-neutral-50 border-[1px] my-10 px-6 py-3 text-neutral-50">
      EYESP.LIVE
    </Link>
  );
};

export default Logo;
